import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CanalesRoutingModule } from './canales-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CanalesRoutingModule
  ]
})
export class CanalesModule { }
