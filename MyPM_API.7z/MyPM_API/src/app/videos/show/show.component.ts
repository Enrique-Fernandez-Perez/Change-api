import { Component } from '@angular/core';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styles: [
  ]
})
export class ShowComponent {
  $width = 100;
  $height = 300;
}
